# emotion detection > 2024-06-04 12:48am
https://universe.roboflow.com/aryans-ws/emotion-detection-cimg7

Provided by a Roboflow user
License: CC BY 4.0

